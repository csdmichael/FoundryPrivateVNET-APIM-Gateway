"""Health check endpoint for the bot Function App."""

import json

import azure.functions as func


def main(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(json.dumps({"status": "ok"}), status_code=200, mimetype="application/json")
